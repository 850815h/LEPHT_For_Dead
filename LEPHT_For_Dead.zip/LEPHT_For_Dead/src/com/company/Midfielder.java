package com.company;

public class Midfielder extends Player {

    public Midfielder(String name, int speed, int dribbling, int passing, int breaking, String position) {
        super(name, speed, dribbling, passing, breaking, position);
    }
}
