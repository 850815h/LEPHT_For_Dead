package com.company;

public class ScoringLeague {
}
